const envList = [{"envId":"cloud1-9g9nu7u34c900ca6","alias":"cloud1"}]
const isMac = true
module.exports = {
    envList,
    isMac
}